document.getElementById('burger-icon').addEventListener('click', function() {
  document.getElementById('navbar-links').classList.toggle('show');
});